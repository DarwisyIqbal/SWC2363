<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yoga and Flexibility</title>
    <link rel="stylesheet" href="Strength.css">
</head>
<body>
    <div class="class-page">
        <h1>YOGA AND FLEXIBILITY</h1>
        <h2>FLOW YOGA™</h2>
        <p>A calming yoga session to deepen flexibility and relaxation. This class combines mindful breathing and stretching poses to relieve stress.</p>
        <div class="info">
            <div class="intensity">
                <strong>Intensity:</strong> Low to Medium
            </div>
            <div class="complexity">
                <strong>Complexity:</strong> Easy
            </div>
            <div class="duration">
                <strong>Duration:</strong> 60 mins
            </div>
        </div>
        <div class="things-to-bring">
            <h3>Things to Bring</h3>
            <ul>
                <li>Yoga Mat</li>
                <li>Water</li>
                <li>Towel</li>
                <li>Comfortable Clothing</li>
            </ul>
        </div>
    </div>
</body>
</html>
