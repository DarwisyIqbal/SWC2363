<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strength and Conditioning</title>
    <link rel="stylesheet" href="Strength.css">
</head>
<body>
    <div class="class-page">
        <h1>STRENGTH AND CONDITIONING</h1>
        <h2>LES MILLS STRENGTH DEVELOPMENT™</h2>
        <p>If you’re wanting to get stronger, this 12-week program focuses on progressive strength building, muscle conditioning, and improving technique.</p>
        <div class="info">
            <div class="intensity">
                <strong>Intensity:</strong> Medium to High
            </div>
            <div class="complexity">
                <strong>Complexity:</strong> Easy to Moderate
            </div>
            <div class="duration">
                <strong>Duration:</strong> 45 mins
            </div>
        </div>
        <div class="things-to-bring">
            <h3>Things to Bring</h3>
            <ul>
                <li>Water</li>
                <li>Towel</li>
                <li>Extra Clothes</li>
                <li>Shoes</li>
            </ul>
        </div>
    </div>
</body>
</html>
