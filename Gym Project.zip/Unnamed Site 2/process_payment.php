<?php
// process_payment.php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $plan = htmlspecialchars($_POST['plan']);

    // Simulate payment success and store payment status
    // (In real systems, this would depend on the payment gateway response)
    echo "Payment for Darwisy Iqbal for the Elite Performance plan was successful!";
}
?>
