<?php
session_start(); // Start the session to access session variables

// Check if the user is logged in and get their username (you can modify this logic as per your authentication system)
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gym Membership</title>
    <link rel="stylesheet" href="stylesGymMem.css">
</head>
<body>

<!-- Membership Section -->
<section>

    	<!-- Add icon library -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Navigation Bar -->
    <header>
        <nav>
            <div class="logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness Logo">
            </div>
            <ul>
                <li><a href="Gym.php"><button class="button"><i class="fa fa-home"></i> Home</button></a></li>
                <li><a href="Membership.php"><button class="button"><i class="fa fa-credit-card"></i> Membership</button></a></li>
                <li><a href="classes.php"><button class="button"><i class="fa fa-users"></i> Classes</button></a></li>
                <li><a href="PersonalTraining.php"><button class="button"><i class="fa fa-dumbbell"></i> Personal Training</button></a></li>
                <li><a href="location.php"><button class="button"><i class="fa fa-map-marker"></i> Locate Our Gym</button></a></li>
                <h3>Welcome, Darwisy!</h3>
            </ul>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="hero-content">
            <h1>Welcome to Street Fitness</h1>
            <h2>Your journey to fitness starts here. Join today and unlock your potential!</h2>
            <a href="#membership" class="button">View Membership Plans</a>
        </div>
    </section>

    <section id="membership" class="membership-plans">
        <h2>JOIN OUR GYM AND ALL ITS ACCESS</h2>

        <div class="plan">
            <h3>Basic Fit</h3>
            <p>MYR109</p>
            <ul>
                <li>General gym equipment (cardio, free weights, machines)</li>
                <li>Access during off-peak hours</li>
                <li>Basic locker room facilities</li>
            </ul>
            <a href="ShopSubscription.php" class="button">Shop Now</a>
        </div>

        <div class="plan">
            <h3>Premium Power</h3>
            <p>MYR139</p>
            <ul>
                <li>Everything in Basic Fit</li>
                <li>Full-day access (peak and off-peak hours)</li>
                <li>Group fitness classes (e.g., yoga, spin, HIIT)</li>
                <li>Fitness assessments (initial assessment + monthly check-ins)</li>
            </ul>
            <a href="ShopSubscription.php" class="button">Shop Now</a>
        </div>

        <div class="plan">
            <h3>Elite Performance</h3>
            <p>MYR179</p>
            <ul>
                <li>Everything in Premium Power</li>
                <li>Unlimited personal training sessions</li>
                <li>Nutrition coaching and meal planning</li>
                <li>Priority booking for classes and equipment</li>
            </ul>
            <a href="ShopSubscription.php" class="button">Shop Now</a>
        </div>
    </section>

<!-- Footer Section -->
<footer>
    <div class="footer-container">
        <div class="footer-logo">
            <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness">
        </div>
        
        <div class="footer-links">
            <ul>
                <li><a href="Membership.php">Membership</a></li>
                <li><a href="PersonalTraining.php">Personal Training</a></li>
                <li><a href="Classes.php">Classes</a></li>
                <li><a href="Profile.php">Profile</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
    </div>
</footer>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const plans = document.querySelectorAll('.plan');

        const fadeInOnScroll = () => {
            plans.forEach(plan => {
                const planPosition = plan.getBoundingClientRect().top;
                const screenPosition = window.innerHeight / 1.3;

                if (planPosition < screenPosition) {
                    plan.classList.add('fade-in');
                }
            });
        };

        window.addEventListener('scroll', fadeInOnScroll);
    });
</script>

</body>
</html>
