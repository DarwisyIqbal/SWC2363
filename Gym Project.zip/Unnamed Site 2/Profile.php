<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Profile - Strength and Conditioning</title>
    <link rel="stylesheet" href="Strength.css">
</head>
<body>
    <div class="class-page">
        <!-- Profile Header -->
        <h1>Welcome, Darwisy Iqbal!</h1>
        <h2>Package: Elite Performance</h2>
        
        
        <!-- Personal Details -->
        <div class="personal-details">
            <p><strong>Membership ID:</strong> 001</p>
            <p><strong>Join Date:</strong> November 25th, 2024</p>
            <p><strong>Membership Expiry:</strong> November 25th, 2025</p>
        </div>

        <!-- Progress Tracking -->
        <div class="progress-section">
            <h3>Progress</h3>
            <div class="progress-bar">
                <span style="width:0%;">0% to Goal</span>
            </div>
        </div>

        <!-- Workout History -->
        <div class="workout-history">
            <h3>Recent Workouts</h3>
            <ul>
                <li>None</li>
               
            </ul>
        </div>

       
    </div>
</body>
</html>
