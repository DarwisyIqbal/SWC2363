<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HIIT</title>
    <link rel="stylesheet" href="Strength.css">
</head>
<body>
    <div class="class-page">
        <h1>HIIT</h1>
        <h2>MAX HIIT™</h2>
        <p>A high-intensity workout designed to maximize calorie burn and endurance in a short period. Perfect for a quick, powerful workout.</p>
        <div class="info">
            <div class="intensity">
                <strong>Intensity:</strong> Very High
            </div>
            <div class="complexity">
                <strong>Complexity:</strong> Moderate
            </div>
            <div class="duration">
                <strong>Duration:</strong> 30 mins
            </div>
        </div>
        <div class="things-to-bring">
            <h3>Things to Bring</h3>
            <ul>
                <li>Water</li>
                <li>Towel</li>
                <li>Extra Clothes</li>
                <li>Shoes</li>
            </ul>
        </div>
    </div>
</body>
</html>
