
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Street Fitness</title>
    <link rel="stylesheet" href="payment.css">
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness Logo">
            </div>
        </nav>
    </header>

    <section class="payment-section">
        <h1>Complete Your Payment</h1>
        <p>Thank you, Darwisy, for choosing the Ultimate Performance plan!</p>

        <p>Please proceed to make your payment.</p>
        <form action="process_payment.php" method="POST">
            <input type="hidden" name="plan" value="<?php echo $plan; ?>">
            <button type="submit" class="pay-button">Pay Now</button>
        </form>
    </section>

    <footer>
        <div class="footer-container">
            <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
