<?php
// Start the session to access session variables if needed
session_start();

// Example: Set a dynamic username (for the welcome message) from session or hardcoded.
$username = isset($_SESSION['username']) ? $_SESSION['username'] : 'Iqbal'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locate Our Gym</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <!-- Navigation Bar -->
    <header>
        <nav>
            <div class="logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness Logo">
            </div>
            <ul>
                <li><a href="Gym.php"><button class="button"><i class="fa fa-home"></i> Home</button></a></li>
                <li><a href="Membership.php"><button class="button"><i class="fa fa-credit-card"></i> Membership</button></a></li>
                <li><a href="classes.php"><button class="button"><i class="fa fa-users"></i> Classes</button></a></li>
                <li><a href="PersonalTraining.php"><button class="button"><i class="fa fa-dumbbell"></i> Personal Training</button></a></li>
                <li><a href="location.php"><button class="button"><i class="fa fa-map-marker"></i> Locate Our Gym</button></a></li>
                <h3>Welcome, Darwisy!</h3>
            </ul>
        </nav>
    </header>

    <main>
        <h1>Locate Our Gym</h1>
        <p>Find our gym location on the map below.</p>
        
        <!-- Google Maps Embed Code -->
        <div class="map-container">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d125990.41989513802!2d101.6555351316874!3d3.124626274946368!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x31cc374474dbfff9%3A0x56b3472b2d8897b!2sLorong%206B%2F91%2C%20Taman%20Shamelin%20Perkasa%2C%2056100%20Kuala%20Lumpur%2C%20Wilayah%20Persekutuan%20Kuala%20Lumpur!3m2!1d3.1246294999999997!2d101.7379371!5e1!3m2!1sen!2smy!4v1731579891057!5m2!1sen!2smy" 
                width="600" 
                height="450" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </main>

    <footer>
        <p>Contact us for more information about our gym location.</p>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness">
            </div>
            
            <div class="footer-links">
                <ul>
                    <li><a href="Membership.php">Membership</a></li>
                    <li><a href="PersonalTraining.php">Personal Training</a></li>
                    <li><a href="Classes.php">Classes</a></li>
                    <li><a href="Profile.php">Profile</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
