

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop Subscription - Street Fitness</title>
    <link rel="stylesheet" href="ShopSub.css">
</head>
<body>

    <header>
        <nav>
            <div class="logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness Logo">
            </div>
        </nav>
    </header>

    <!-- Shop Subscription Form Section -->
    <section class="shop-subscription">
        <h1>Shop Your Subscription</h1>
        <p>Choose the plan that best suits your fitness goals and enjoy access to top facilities and expert guidance.</p>

        <form action="Payment.php" method="POST" class="subscription-form">

            <div class="input-container">
                <label for="first-name">First Name</label>
                <input type="text" id="first-name" name="first-name" placeholder="Enter your first name" required>
            </div>

            <div class="input-container">
                <label for="last-name">Last Name</label>
                <input type="text" id="last-name" name="last-name" placeholder="Enter your last name" required>
            </div>

            <div class="input-container">
                <label for="dob">Date of Birth</label>
                <input type="date" id="dob" name="dob" required>
            </div>

            <div class="input-container">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>

            <div class="input-container">
                <label for="mobile">Mobile Number</label>
                <input type="tel" id="mobile" name="mobile" placeholder="Enter your mobile number" required>
            </div>

            <div class="input-container">
                <label for="plan">Select Your Plan</label>
                <select id="plan" name="plan" required>
                    <option value="" disabled selected>Select a plan</option>
                    <option value="basic-fit">Basic Fit - MYR109</option>
                    <option value="premium-power">Premium Power - MYR139</option>
                    <option value="elite-performance">Elite Performance - MYR179</option>
                </select>
            </div>

            <div class="input-container">
    <a href="Payment.php" class="button">Subscribe Now</a>
</div>

        </form>
    </section>

    <!-- Footer Section -->
    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness">
            </div>
            <div class="footer-links">
                <ul>
                    <li><a href="Membership.php">Membership</a></li>
                    <li><a href="PersonalTraining.php">Personal Training</a></li>
                    <li><a href="Classes.php">Classes</a></li>
                    <li><a href="Profile.php">Profile</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
