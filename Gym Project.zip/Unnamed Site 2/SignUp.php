<?php
// Include database connection
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $first_name = mysqli_real_escape_string($conn, $_POST['first-name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last-name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm-password']);

    // Validate the passwords match
    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match.');</script>";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if email already exists
        $email_check_query = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
        $result = mysqli_query($conn, $email_check_query);
        $user = mysqli_fetch_assoc($result);

        if ($user) {
            echo "<script>alert('Email already exists. Please use another email.');</script>";
        } else {
            // Insert the new user into the database
            $query = "INSERT INTO users (first_name, last_name, email, password) 
                      VALUES ('$first_name', '$last_name', '$email', '$hashed_password')";
            if (mysqli_query($conn, $query)) {
                echo "<script>alert('Registration successful!');</script>";
                header("Location: login.php");  // Redirect to login page after successful registration
                exit;
            } else {
                echo "<script>alert('Error: " . mysqli_error($conn) . "');</script>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Street Fitness</title>
    <link rel="stylesheet" href="Login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

    <!-- Navigation Bar (Header) -->
    <header>
        <nav>
            <div class="logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness Logo">
            </div>
        </nav>
    </header>

    <!-- Sign Up Section -->
    <section class="signup-section">
        <h1>Create Your Account</h1>
        <p>Join us today and take the first step towards a healthier you. Fill out the form below to get started.</p>
        
        <!-- Sign Up Form -->
        <div class="signup-form-container">
            <form action="signup.php" method="POST" class="signup-form">
                <div class="input-container">
                    <label for="first-name">First Name</label>
                    <input type="text" id="first-name" name="first-name" placeholder="Enter your first name" required>
                </div>
                <div class="input-container">
                    <label for="last-name">Last Name</label>
                    <input type="text" id="last-name" name="last-name" placeholder="Enter your last name" required>
                </div>
                <div class="input-container">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" required>
                </div>
                <div class="input-container">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Create a password" required>
                </div>
                <div class="input-container">
                    <label for="confirm-password">Confirm Password</label>
                    <input type="password" id="confirm-password" name="confirm-password" placeholder="Confirm your password" required>
                </div>
                
                <div class="terms-container">
                    <label>
                        <input type="checkbox" required> I agree to the <a href="terms.html">Terms and Conditions</a>
                    </label>
                </div>
                
                <button type="submit" class="signup-button">Sign Up</button>
                <div class="links">
                    <p>Already have an account? <a href="login.php">Log In</a></p>
                </div>
            </form>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness">
            </div>
            <div class="footer-links">
                <ul>
                    <li><a href="Membership.php">Membership</a></li>
                    <li><a href="PersonalTraining.php">Personal Training</a></li>
                    <li><a href="Classes.php">Classes</a></li>
                    <li><a href="Profile.php">Profile</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
