<?php
// db.php: This file should contain your database connection
include('db.php');

// Fetch classes
$sql = "SELECT * FROM classes";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Classes</title>
    <link rel="stylesheet" href="ClassesStyles.css">
</head>
<body>

    <!-- Classes section -->
    <section>
        <!-- Add icon library -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

        <!-- Navigation Bar -->
        <header>
            <nav>
                <div class="logo">
                    <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness Logo">
                </div>
                <ul>
                    <li><a href="Gym.php"><button class="button"><i class="fa fa-home"></i> Home</button></a></li>
                    <li><a href="Membership.php"><button class="button"><i class="fa fa-credit-card"></i> Membership</button></a></li>
                    <li><a href="classes.php"><button class="button"><i class="fa fa-users"></i> Classes</button></a></li>
                    <li><a href="PersonalTraining.php"><button class="button"><i class="fa fa-dumbbell"></i> Personal Training</button></a></li>
                    <li><a href="location.php"><button class="button"><i class="fa fa-map-marker"></i> Locate Our Gym</button></a></li>
                    <h3>  Welcome, Darwisy!</h3>
                </ul>
            </nav>
        </header>

    
        <!-- Body section -->
        <div class="slider-container">
            <div class="slider">
                <div class="slide" style="background-image: url('Images/Podcast\ #187_\ Improving\ Strength\ &\ Durability\ With\ the\ Kabuki\ Movement\ System.jpg');">
                    <div class="slide-content">
                        <h3>Strength and Conditioning</h3>
                        <h2>LES MILLS TONE</h2>
                        <a href="StrengthCond.php"><button class="view-class">View class</button></a>
                    </div>
                </div>
                <div class="slide" style="background-image: url('Images/How\ to\ Shed\ Body\ Fat\ After\ Bulking\ Up\ _\ Livestrong_com.jpg');">
                    <div class="slide-content">
                        <h3>Cardio</h3>
                        <h2>LES MILLS CARDIO</h2>
                        <a href="Cardio.php"><button class="view-class">View class</button></a>
                    </div>
                </div>
                <div class="slide" style="background-image: url('Images/30\ Yoga\ Photography\ Tips\ and\ Ideas.jpg');">
                    <div class="slide-content">
                        <h3>Yoga and Flexibility</h3>
                        <h2>LES MILLS YOGA</h2>
                        <a href="Yoga.php"><button class="view-class">View class</button></a>
                    </div>
                </div>
                <div class="slide" style="background-image: url('Images/Step\ _\ qu’est\ ce\ que\ la\ step\ dance\ -\ Elle.jpg');">
                    <div class="slide-content">
                        <h3>Dance</h3>
                        <h2>LES MILLS DANCE</h2>
                        <a href="Dance.php"><button class="view-class">View class</button></a>
                    </div>
                </div>
                <div class="slide" style="background-image: url('Images/The\ 8\ Best\ Dumbbell\ Moves\ For\ Chest\ Development.jpg');">
                    <div class="slide-content">
                        <h3>HIIT</h3>
                        <h2>LES MILLS HIIT</h2>
                        <a href="HIIT.php"><button class="view-class">View class</button></a>
                    </div>
                </div>
            </div>
        </div>
        
            <div class="nav-buttons">
                <button class="prev">&#10094;</button>
                <button class="next">&#10095;</button>
            </div>
        </div>
    
</section>
    
<!--Footer Section-->
<footer>
    <div class="footer-container">
        <div class="footer-logo">
            <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness">
        </div>
        
        <div class="footer-links">
            <ul>
                <li><a href="Membership.html">Membership</a></li>
                <li><a href="PersonalTraining.html">Personal Training</a></li>
                <li><a href="Classes.html">Classes</a></li>
                <li><a href="#profile">Profile</a></li>

            </ul>
        </div>
        
       
    </div>
    <div class="footer-bottom">
        <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
    </div>
</footer>




    <!-- JavaScript for Body scroll-->
    <script>
        let currentIndex = 0;
        const slides = document.querySelectorAll('.slide');

        function showSlide(index) {
            if (index >= slides.length) {
                currentIndex = 0;
            } else if (index < 0) {
                currentIndex = slides.length - 1;
            } else {
                currentIndex = index;
            }

            const offset = -currentIndex * 100;
            document.querySelector('.slider').style.transform = `translateX(${offset}%)`;

            slides.forEach((slide, idx) => {
                slide.style.opacity = idx === currentIndex ? '1' : '0.5';
                slide.style.transform = idx === currentIndex ? 'scale(1)' : 'scale(0.95)';
            });
        }

        document.querySelector('.prev').addEventListener('click', () => showSlide(currentIndex - 1));
        document.querySelector('.next').addEventListener('click', () => showSlide(currentIndex + 1));

        showSlide(currentIndex);
    </script>
</body>
</html>
