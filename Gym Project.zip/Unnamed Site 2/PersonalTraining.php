<?php
// Start session to manage user login
session_start();

// Example user session data
$_SESSION['username'] = 'Iqbal';

// Sample timetable data (can be replaced with a database query later)
$timetable = [
    "Monday" => [
        ["time" => "7:00 AM - 8:00 AM", "class" => "Strength and Conditioning"],
        ["time" => "5:00 PM - 6:00 PM", "class" => "Cardio"],
    ],
    "Tuesday" => [
        ["time" => "8:00 AM - 9:00 AM", "class" => "Yoga and Flexibility"],
        ["time" => "6:00 PM - 7:00 PM", "class" => "HIIT"],
    ],
    "Wednesday" => [
        ["time" => "7:00 AM - 8:00 AM", "class" => "Strength and Conditioning"],
        ["time" => "5:00 PM - 6:00 PM", "class" => "Yoga and Flexibility"],
    ],
    "Thursday" => [
        ["time" => "8:00 AM - 9:00 AM", "class" => "HIIT"],
        ["time" => "6:00 PM - 7:00 PM", "class" => "Dance"],
    ],
    "Friday" => [
        ["time" => "7:00 AM - 8:00 AM", "class" => "Cardio"],
        ["time" => "5:00 PM - 6:00 PM", "class" => "Yoga and Flexibility"],
    ],
    "Saturday" => [
        ["time" => "9:00 AM - 10:00 AM", "class" => "Strength and Conditioning"],
        ["time" => "10:30 AM - 11:30 AM", "class" => "HIIT"],
    ],
    "Sunday" => [
        ["time" => "8:00 AM - 9:00 AM", "class" => "Restorative Yoga"],
        ["time" => "5:00 PM - 6:00 PM", "class" => "Stretch & Flex"],
    ],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Training</title>
    <link rel="stylesheet" href="Training.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <!-- Navigation Bar (Header) -->
    <header>
        <nav>
            <div class="logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness Logo">
            </div>
            <ul>
                <li><a href="Gym.php"><button class="button"><i class="fa fa-home"></i> Home</button></a></li>
                <li><a href="Membership.php"><button class="button"><i class="fa fa-credit-card"></i> Membership</button></a></li>
                <li><a href="classes.php"><button class="button"><i class="fa fa-users"></i> Classes</button></a></li>
                <li><a href="PersonalTraining.php"><button class="button"><i class="fa fa-dumbbell"></i> Personal Training</button></a></li>
                <li><a href="location.php"><button class="button"><i class="fa fa-map-marker"></i> Locate Our Gym</button></a></li>
                <h3>Welcome, Darwisy!</h3>
            </ul>
        </nav>
    </header>

    <!-- Body Content -->
    <section class="personal-training-content">
        <h1>Personal Training</h1>
        <p>Experience the benefits of personalized training designed to fit your goals and needs.</p>

        <!-- Benefits of Personal Training -->
        <div class="benefits">
            <h2>START TRAINING WITH US TODAY</h2>
            <h1>FROM MYR120/HOUR</h1>
            <ul>
                <li><i class="fa fa-check-circle"></i> Tailored workout plans for your goals</li>
                <li><i class="fa fa-check-circle"></i> One-on-one expert guidance</li>
                <li><i class="fa fa-check-circle"></i> Faster results with proper technique</li>
                <li><i class="fa fa-check-circle"></i> Motivation and accountability</li>
                <li><i class="fa fa-check-circle"></i> Flexible schedule</li>
            </ul>
        </div>
    </section>
    
    <!-- Timetable Section -->
    <div class="timetable-section">
        <h2>Class Timetable</h2>
        <div class="timetable-container">
            <?php foreach ($timetable as $day => $sessions): ?>
                <div class="day">
                    <h3><?php echo $day; ?></h3>
                    <ul>
                        <?php foreach ($sessions as $session): ?>
                            <li>
                                <span><?php echo $session['time']; ?></span> 
                                <strong><?php echo $session['class']; ?></strong>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Footer Section -->
    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness">
            </div>
            <div class="footer-links">
                <ul>
                    <li><a href="Membership.php">Membership</a></li>
                    <li><a href="PersonalTraining.php">Personal Training</a></li>
                    <li><a href="Classes.php">Classes</a></li>
                    <li><a href="Profile.php">Profile</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
