<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dance Fusion</title>
    <link rel="stylesheet" href="Strength.css">
</head>
<body>
    <div class="class-page">
        <h1>DANCE</h1>
        <h2>DANCE FUSION™</h2>
        <p>An upbeat dance class that combines various dance styles for a fun, calorie-burning workout. Great for all levels.</p>
        <div class="info">
            <div class="intensity">
                <strong>Intensity:</strong> Medium to High
            </div>
            <div class="complexity">
                <strong>Complexity:</strong> Moderate
            </div>
            <div class="duration">
                <strong>Duration:</strong> 50 mins
            </div>
        </div>
        <div class="things-to-bring">
            <h3>Things to Bring</h3>
            <ul>
                <li>Water</li>
                <li>Towel</li>
                <li>Dance Sneakers</li>
                <li>Comfortable Clothing</li>
            </ul>
        </div>
    </div>
</body>
</html>
