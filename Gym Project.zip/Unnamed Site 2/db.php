<?php
$servername = "localhost";  // Database server (default is localhost)
$username = "root";         // Database username (default for XAMPP)
$password = "";             // Database password (default is empty for XAMPP)
$dbname = "gym_database";   // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
