<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cardio Blast</title>
    <link rel="stylesheet" href="Strength.css">
</head>
<body>
    <div class="class-page">
        <h1>CARDIO</h1>
        <h2>CARDIO BLAST™</h2>
        <p>A high-energy cardio session designed to increase endurance and stamina with various movements. Perfect for all fitness levels.</p>
        <div class="info">
            <div class="intensity">
                <strong>Intensity:</strong> High
            </div>
            <div class="complexity">
                <strong>Complexity:</strong> Moderate
            </div>
            <div class="duration">
                <strong>Duration:</strong> 30 mins
            </div>
        </div>
        <div class="things-to-bring">
            <h3>Things to Bring</h3>
            <ul>
                <li>Water</li>
                <li>Towel</li>
                <li>Heart Rate Monitor</li>
                <li>Shoes</li>
            </ul>
        </div>
    </div>
</body>
</html>
