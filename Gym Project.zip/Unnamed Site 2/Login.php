<?php
// Start session
session_start();

// Include the database connection
include 'db.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare the SQL query to fetch user details
    $stmt = $conn->prepare("SELECT id, email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if user exists
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            
            // Redirect to the Gym page or profile
            header("Location: Gym.php");
            exit;
        } else {
            $error_message = "Incorrect password. Please try again.";
        }
    } else {
        $error_message = "Username not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Street Fitness</title>
    <link rel="stylesheet" href="Login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>

    <!-- Navigation Bar (Header) -->
    <header>
        <nav>
            <div class="logo">
                <img src="Images/2024-10-01.png" alt="Street Fitness Logo">
            </div>
        </nav>
    </header>

    <!-- Login Section -->
    <section class="login-section">
        <h1>Login to Your Account</h1>
        <p>Welcome back! Please enter your details to access your account.</p>

        <!-- Display error message if any -->
        <?php if (!empty($error_message)): ?>
            <p class="error-message"><?php echo $error_message; ?></p>
        <?php endif; ?>
        
        <!-- Login Form -->
        <div class="login-form-container">
            <form action="login.php" method="POST" class="login-form">
                <div class="input-container">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" placeholder="Enter your username" required>
                </div>
                <div class="input-container">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                </div>

                <!-- Remember Me Checkbox -->
                <div class="remember-me">
                    <label>
                        <input type="checkbox" id="remember-me"> Remember me
                    </label>
                </div>

                <button type="submit" class="login-button">Log In</button>

                <!-- Links for Forgot Password and Sign Up -->
                <div class="links">
                    <a href="forgot-password.html">Forgot Password?</a>
                    <a href="SignUp.php">Don't have an account? Sign Up</a>
                </div>
            </form>
        </div>
    </section>

    <!-- Footer Section -->
    <footer>
        <div class="footer-container">
            <div class="footer-logo">
                <img src="Images/Screenshot 2024-10-01 153036.png" alt="Street Fitness">
            </div>
            <div class="footer-links">
                <ul>
                    <li><a href="Membership.php">Membership</a></li>
                    <li><a href="PersonalTraining.php">Personal Training</a></li>
                    <li><a href="Classes.php">Classes</a></li>
                    <li><a href="profile.php">Profile</a></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 Sportathlon (Malaysia) Sdn. Bhd. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
